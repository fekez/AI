﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChessPractise
{
    internal class FigureDetails
    {
        //Initialize
        private FigureType _figureTypes { get; set; }
        private bool _side { get; }

        //Getters
        public int FigureTypes
        {
            get { return (int)_figureTypes; }
        }

        public bool Side
        {
            get { return _side; }  
        }

        //Constructors
        public FigureDetails(FigureType figureType, bool side)
        {
            _figureTypes = figureType;
            _side = side;
        }


        public enum FigureType : byte
        {
            pawn = 1,
            bishop = 3,
            knight = 4,
            rook = 5,
            queen = 9,
            king = 42
        }
    }
}
