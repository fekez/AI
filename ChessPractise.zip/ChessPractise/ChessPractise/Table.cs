﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChessPractise
{
    internal class Table
    {
        private Dictionary<char, Dictionary<int, Cell>> _board { get;}
        private bool _side { get; }

        public Dictionary<char, Dictionary<int, Cell>> Board
        {
            get { return _board; }
        }

        public bool Side
        {
            get { return _side; }
        }

        public Table(bool side)
        {
            _board = new Dictionary<char, Dictionary<int, Cell>>();
            _side = side;

            for(char i = 'A'; i <= 'H'; i++)
            {
                _board.Add(i, new Dictionary<int, Cell>());

                for(int j = 1; j <= 8; j++)
                {
                    //Add Pawns
                    if(j == 2)
                    {
                        _board[i].Add(j, new Cell(i, j, new Pawn(new FigureDetails(FigureDetails.FigureType.pawn, side))));
                    }
                    else if(j == 7)
                    {
                        _board[i].Add(j, new Cell(i, j, new Pawn(new FigureDetails(FigureDetails.FigureType.pawn, !side))));
                    }

                    //Add Rooks
                    else if(j == 1 && (i == 'A' || i == 'H'))
                    {
                        _board[i].Add(j, new Cell(i, j, new Rook(new FigureDetails(FigureDetails.FigureType.rook, side))));
                    }
                    else if (j == 8 && (i == 'A' || i == 'H'))
                    {
                        _board[i].Add(j, new Cell(i, j, new Rook(new FigureDetails(FigureDetails.FigureType.rook, !side))));
                    }

                    //Add Knights
                    else if (j == 1 && (i == 'B' || i == 'G'))
                    {
                        _board[i].Add(j, new Cell(i, j, new Knight(new FigureDetails(FigureDetails.FigureType.knight, side))));
                    }
                    else if (j == 8 && (i == 'B' || i == 'G'))
                    {
                        _board[i].Add(j, new Cell(i, j, new Knight(new FigureDetails(FigureDetails.FigureType.knight, !side))));
                    }

                    //Add Bishops
                    else if (j == 1 && (i == 'C' || i == 'F'))
                    {
                        _board[i].Add(j, new Cell(i, j, new Bishop(new FigureDetails(FigureDetails.FigureType.bishop, side))));
                    }
                    else if (j == 8 && (i == 'C' || i == 'F'))
                    {
                        _board[i].Add(j, new Cell(i, j, new Bishop(new FigureDetails(FigureDetails.FigureType.bishop, !side))));
                    }

                    //Add Queen
                    else if (j == 1 && i == 'D')
                    {
                        _board[i].Add(j, new Cell(i, j, new Queen(new FigureDetails(FigureDetails.FigureType.queen, side))));
                    }
                    else if (j == 8 && i == 'D')
                    {
                        _board[i].Add(j, new Cell(i, j, new Queen(new FigureDetails(FigureDetails.FigureType.queen, !side))));
                    }

                    //Add Queen
                    else if (j == 1 && i == 'E')
                    {
                        _board[i].Add(j, new Cell(i, j, new King(new FigureDetails(FigureDetails.FigureType.king, side))));
                    }
                    else if (j == 8 && i == 'E')
                    {
                        _board[i].Add(j, new Cell(i, j, new King(new FigureDetails(FigureDetails.FigureType.king, !side))));
                    }

                    //Empty cells
                    else
                    {
                        _board[i].Add(j, new Cell(i, j));
                    }

                    
                }
            }
        }

        public override string ToString()
        {
            StringBuilder stringBuilder = new StringBuilder();
            foreach(var column in _board)
            {
                stringBuilder.Append(" " + column.Key + " |  ");

                foreach (var cell in column.Value)
                {
                    stringBuilder.Append(cell.Value.ToString() + "\t");
                }
                stringBuilder.Append("\n   |\n");
            }

            stringBuilder.Append("\t");
            foreach (var number in _board['A'].Keys)
            {
                stringBuilder.Append(number.ToString() + "\t");
            }

            stringBuilder.Append("\n");

            return stringBuilder.ToString();
        }

        public string printCellListToBoard(List<Cell> cellList, bool side)
        {
            StringBuilder stringBuilder = new StringBuilder();
            foreach (var column in _board)
            {
                foreach (var cell in column.Value)
                {
                    if (cellList.Contains(cell.Value))
                    {
                        stringBuilder.Append("OO" + "\t");

                        if (cell.Value.Figure != null && cell.Value.Figure.getSide() == !side)
                        {
                            stringBuilder.Append("XX" + "\t");
                        }
                    }
                    else
                    {
                        stringBuilder.Append(cell.Value.ToString() + "\t");
                    }

                }
                stringBuilder.Append("\n");
            }

            return stringBuilder.ToString();
        }

        public string printCellListToBoard(List<Cell> cellList1, List<Cell> cellList2)
        {
            StringBuilder stringBuilder = new StringBuilder();
            foreach (var column in _board)
            {
                foreach (var cell in column.Value)
                {
                    if (cellList1.Contains(cell.Value))
                    {
                        stringBuilder.Append("OO" + "\t");
                    }
                    else if (cellList2.Contains(cell.Value))
                    {
                        stringBuilder.Append("XX" + "\t");
                    }
                    else
                    {
                        stringBuilder.Append(cell.Value.ToString() + "\t");
                    }

                }
                stringBuilder.Append("\n");
            }

            return stringBuilder.ToString();
        }

        public void setRanges(Cell cellOfFigure)
        {
            _board[cellOfFigure.Column][cellOfFigure.Row].Figure.setFiguresInRange(_board[cellOfFigure.Column][cellOfFigure.Row], _board);
        }
    }
}
