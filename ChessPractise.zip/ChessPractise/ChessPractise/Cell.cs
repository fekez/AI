﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChessPractise
{
    internal class Cell
    {
        //Initialize
        private char _column { get; }
        private int _row { get; } 

        private IFigure? _figure { get; set; }

        //Getters, Setters
        public char Column
        {
            get { return _column; }
        }

        public int Row
        {
            get { return _row; }
        }

        public IFigure? Figure
        {
            get { return _figure; }
            set { _figure = value; }
        }

        //Constructors
        public Cell(char column, int row)
        {
            _column = column;
            _row = row;
            _figure = null;
        }

        public Cell(char column, int row, IFigure? figure)
        {
            _column = column;
            _row = row;
            _figure = figure;
        }

        //Methods
        public override string ToString()
        {
            return _figure != null ? (!_figure.getSide() ? "0" : "1") + _figure.getFigureType() : "--";
        }

        public bool isEquelCell(Cell cell)
        {
            return _column == cell.Column && _row == cell._row;
        }

        public void moveCells(Cell cell)
        {
            if (cell != null)
            {
                this.Figure = cell.Figure;
                cell.Figure = null;
            }
        }
    }
}
