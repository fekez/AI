﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChessPractise
{
    internal class Rook : IFigure
    {
        //Initialize
        private FigureDetails _figureDetails { get; set; }
        private List<Cell> _emptyCells { get; }
        private List<Cell> _enemies { get; }


        //Constructors
        public Rook(FigureDetails figureDetails)
        {
            _figureDetails = figureDetails;
            _emptyCells = new List<Cell>();
            _enemies = new List<Cell>();
        }

        //Implements interface methodes
        public string getFigureType()
        {
            return _figureDetails.FigureTypes.ToString();
        }

        public bool getSide()
        {
            return _figureDetails.Side;
        }

        public List<Cell> getEmptyCells()
        {
            return _emptyCells;
        }

        public List<Cell> getEnemies()
        {
            return _enemies;
        }

        public void setFiguresInRange(Cell position, Dictionary<char, Dictionary<int, Cell>> table)
        {
            if (position.Figure != null)
            {
                _emptyCells.Clear();
                _enemies.Clear();

                checkCells(1, 0, position, table);
                checkCells(-1, 0, position, table);
                checkCells(0, 1, position, table);
                checkCells(0, -1, position, table);
            }
        }


        //helps for getFiguresInRange
        private void checkCells(int prefixColumn, int prefixRow, Cell position, Dictionary<char, Dictionary<int, Cell>> table)
        {
            int i = 0;
            char column;
            int row;
            bool condition = true;
            do
            {
                i++;
                column = (char)(position.Column + i * prefixColumn);
                row = position.Row + i * prefixRow;

                if (table.ContainsKey(column) && table[column].ContainsKey(row))
                {
                    condition = true;
                    if (table[column][row].Figure != null)
                    {
                        condition = false;
                        if (table[column][row].Figure.getSide() != position.Figure.getSide())
                        {
                            _enemies.Add(table[column][row]);
                        }
                    }
                    else
                    {
                        _emptyCells.Add(table[column][row]);
                    }
                }
                else
                {
                    condition = false;
                }

            } while (condition);

        }
    }
}
