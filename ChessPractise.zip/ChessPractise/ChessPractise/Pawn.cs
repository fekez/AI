﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChessPractise
{
    internal class Pawn : IFigure
    {
        //Initialize
        private FigureDetails _figureDetails { get; set; }
        private List<Cell> _emptyCells { get; }
        private List<Cell> _enemies { get; }

        //Constructors
        public Pawn(FigureDetails figureDetails)
        {
            _figureDetails = figureDetails;
            _emptyCells = new List<Cell>();
            _enemies = new List<Cell>();
        }

        //Implements interface methodes
        public string getFigureType()
        {
            return _figureDetails.FigureTypes.ToString();
        }

        public bool getSide()
        {
            return _figureDetails.Side;
        }

        public List<Cell> getEmptyCells()
        {
            return _emptyCells;
        }

        public List<Cell> getEnemies()
        {
            return _enemies;
        }

        public void setFiguresInRange(Cell position, Dictionary<char, Dictionary<int, Cell>> table)
        {
            if (position.Figure != null)
            {
                _emptyCells.Clear();
                _enemies.Clear();

                checkCells(position, table, getSide() ? -1 : 1);
            }
        }


        //helps for getFiguresInRange
        private void checkCells(Cell position, Dictionary<char, Dictionary<int, Cell>> table, int prefix)
        {
            if(table[position.Column][position.Row + prefix].Figure == null)
            {
                _emptyCells.Add(table[position.Column][position.Row + prefix]);

                if(position.Row == (prefix < 1 ? 7 : 2) && table[position.Column][position.Row + 2 * prefix].Figure == null)
                {
                    _emptyCells.Add(table[position.Column][position.Row + 2 * prefix]);
                }

            }

            if(table.ContainsKey((char)(position.Column - 1)) && 
               table[(char)(position.Column - 1)].ContainsKey(position.Row + prefix) &&
               table[(char)(position.Column - 1)][position.Row + prefix].Figure != null &&
               table[(char)(position.Column - 1)][position.Row + prefix].Figure.getSide() != position.Figure.getSide())
            {
                _enemies.Add(table[(char)(position.Column - 1)][position.Row + prefix]);
            }

            if (table.ContainsKey((char)(position.Column + 1)) &&
               table[(char)(position.Column + 1)].ContainsKey(position.Row + prefix) &&
               table[(char)(position.Column + 1)][position.Row + prefix].Figure != null &&
               table[(char)(position.Column + 1)][position.Row + prefix].Figure.getSide() != position.Figure.getSide())
            {
                _enemies.Add(table[(char)(position.Column + 1)][position.Row + prefix]);
            }

        }
    }
}
