﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChessPractise
{
    internal interface IFigure
    {
        public void setFiguresInRange(Cell position, Dictionary<char, Dictionary<int, Cell>> table);
        public string getFigureType();
        public bool getSide();
        public List<Cell> getEmptyCells();
        public List<Cell> getEnemies();
        
    }
}
