﻿using System;

namespace ChessPractise
{
    internal class Program
    {
        static void Main(string[] args)
        {
            CellAndTableManagment game = new CellAndTableManagment();

            game.game();
        }
    }
}
