﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChessPractise
{
    internal class CellAndTableManagment
    {
        //Intitialize
        private Table _table;
        private List<Cell> _figurePositionCellList { get; }
        private List<Cell> _figureFreeCellList { get; }
        private List<Cell> _takenableFigureList { get; }
        private const bool _side = false;

        //Constructe
        public CellAndTableManagment()
        {
            _table = new Table(_side);
            _figurePositionCellList = new List<Cell>();
            _figureFreeCellList = new List<Cell>();
            _takenableFigureList = new List<Cell>();
        }

        //Getters
        public List<Cell> EnemyPositions
        {
            get { return _figurePositionCellList; }
        }

        public List<Cell> FreeCells
        {
            get { return _figureFreeCellList; }
        }

        public List<Cell> TakeFigureList
        {
            get { return _takenableFigureList; }
        }

        //Methods
        public void setFigurePositionCellList(bool side)
        {
            _figurePositionCellList.Clear();

            foreach(var column in _table.Board.Values)
            {
                foreach(var cell in column.Values)
                {
                    if(cell.Figure != null && cell.Figure.getSide() != side)
                    {
                        _figurePositionCellList.Add(cell);
                    }
                }
            }
        }

        public void setFigureFreeAndTakenableCellList(bool side)
        {
            setFigurePositionCellList(!side);
            _figureFreeCellList.Clear();

            foreach (var cell in _figurePositionCellList)
            {
                if(cell != null && cell.Figure != null)
                {
                    cell.Figure.setFiguresInRange(cell, _table.Board);

                    foreach(var emptyCell in cell.Figure.getEmptyCells())
                    {
                        if(!_figureFreeCellList.Contains(emptyCell))
                        {
                            _figureFreeCellList.Add(emptyCell);
                        }
                    }

                    foreach (var targetCell in cell.Figure.getEnemies())
                    {
                        if (!_takenableFigureList.Contains(targetCell))
                        {
                            _takenableFigureList.Add(targetCell);
                        }
                    }
                }
            }
        }

        public void moveCell(Cell startPosition, Cell endPosition)
        {
            endPosition.moveCells(startPosition);
        }

        public override string ToString()
        {
            return _table.ToString();
        }

        //moveCell(Cell, Cell)
        //setFigureFreeAndTakenableCellList(bool)
        //_table.printCellListToBoard(List<Cell>, List<Cell>)
        //_table.ToString()
        //_table.printeRanges

        public void game()
        {
            randomGamePlay(_side);
        }

        public bool randomGamePlay(bool side)
        {
            Console.WriteLine(_table.ToString());

            if(side == _side)
            {
                Cell fromCell = null;
                do
                {
                    Console.Write("From cell ");
                    fromCell = getInputMove();
                } while (_table.Board[fromCell.Column][fromCell.Row].Figure == null || _table.Board[fromCell.Column][fromCell.Row].Figure.getSide() != side);

                _table.setRanges(_table.Board[fromCell.Column][fromCell.Row]);

                Console.WriteLine(_table.printCellListToBoard(_table.Board[fromCell.Column][fromCell.Row].Figure.getEmptyCells(), _table.Board[fromCell.Column][fromCell.Row].Figure.getEnemies()));

                Cell toCell = null;
                do
                {
                    Console.Write("To cell ");
                    toCell = getInputMove();

                } while (!_table.Board[fromCell.Column][fromCell.Row].Figure.getEmptyCells().Contains(_table.Board[toCell.Column][toCell.Row]) &&
                            !_table.Board[fromCell.Column][fromCell.Row].Figure.getEnemies().Contains(_table.Board[toCell.Column][toCell.Row]));

                _table.Board[toCell.Column][toCell.Row].moveCells(_table.Board[fromCell.Column][fromCell.Row]);

                Console.WriteLine(_table.ToString());

                return !side;
            }

            return false;

            
        }

        private Cell getInputMove()
        {
            string input;
            char column = 'Z';
            string rowString = "10";
            int rowInt = 1;

            try
            {
                bool condition = false;
                do
                {
                    Console.Write("input: ");
                    input = Console.ReadLine();
                    if (input != null && input.Length > 1)
                    {
                        column = input[0].ToString().ToUpper().ToCharArray()[0];
                        rowString = input[1].ToString();
                        rowInt = System.Convert.ToInt32(rowString);
                    }
                } while (column < 'A' || column > 'G' || rowInt < 1 || rowInt > 8);

                return new Cell(column, rowInt);
            }
            catch (Exception ex)
            {
                return getInputMove();
            }
        }

    }
}
