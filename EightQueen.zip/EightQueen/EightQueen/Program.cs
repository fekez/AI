﻿using System.Threading;

namespace EightQueen
{
    internal class Program
    {
        public static int numberOfQuuens = getQueensOfNumber();
        public static TableManagment table = new TableManagment(numberOfQuuens);
        static void Main(string[] args)
        {
            var stackSize = 10000000 * (int)System.Math.Pow(10, numberOfQuuens / 3);
            Thread thread = new Thread(new ThreadStart(BigRecursion), stackSize);
            thread.Start();
            thread.Join();

            table.writeResults();
            System.Console.WriteLine("All results count: " + table.getResultsCount());
        }

        private static void BigRecursion()
        {
            table.dumpQueen('A');
        }

        private static int getQueensOfNumber()
        {
            int number = 4;

            try
            {
                System.Console.Clear();
                System.Console.WriteLine("Please, give the size the chessboard! (4-10)");
                string input = System.Console.ReadLine();
                number = int.Parse(input);
            }
            catch
            {
                getQueensOfNumber();
            }

            if(number < 4 || number > 12)
            {
                getQueensOfNumber();
            }

            return number;
        }
    }
}
