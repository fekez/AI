﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EightQueen
{
    internal class TableManagment
    {
        private Stack<Queen> _queens;
        private ChessTable _table;
        private Queen _lastQueenPosiition;
        private List<string> _results;

        public TableManagment(int number)
        {
            _queens = new Stack<Queen>();
            _lastQueenPosiition = null;
            _table = new ChessTable(number);
            _table.createTable();
            _results = new List<string>();
        }

        public void writeResults()
        {
            foreach (var result in _results)
            {
                Console.WriteLine(result);
            }
        }

        public int getResultsCount() => _results.Count;

        public override string ToString()
        {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.Clear();
            stringBuilder.Append(_table.ToString());

            if (_lastQueenPosiition != null)
            {
                stringBuilder.Append("LastQueen: " + _lastQueenPosiition.ToString() + "\n");
            }

            stringBuilder.Append("Queens: ");
            foreach (var queen in _queens)
            {
                stringBuilder.Append(queen.ToString());
            }
            stringBuilder.Append("\n\n");

            return stringBuilder.ToString();
        }

        public int countOfResults()
        {
            return _results.Count;
        }

        private void _stepBack(char rowIndex)
        {
            _table.Table.Clear();
            _table.createTable();
            if (_queens.Count > 0)
            {
                _lastQueenPosiition = _queens.Pop();
            }

            foreach (var item in _queens)
            {
                _table.removeQueenRange(item);
            }

            dumpQueen(--rowIndex);
        }

        private void _stepForward(char rowIndex, int column)
        {
            _lastQueenPosiition = new Queen(rowIndex, column);
            _queens.Push(_lastQueenPosiition);
            _table.removeQueenRange(_lastQueenPosiition);
            dumpQueen(++rowIndex);
        }


        public void dumpQueen(char rowIndex)
        {
            if(_queens.Count == _table.NumberOfQueens)
            {
                addResult();

                //show game
                //Console.WriteLine("Step Back");
                //Console.WriteLine(ToString());
                //Console.WriteLine(_results.Count + "----------------------Found Result!--------------------");

                _stepBack(rowIndex);
            }
            else
            {
                if (_table.Table.ContainsKey(rowIndex))
                {
                    if (_table.getCountOfRowFreeCell(rowIndex) > 0)
                    {
                        int biggerColumn;
                        bool isBiggerColumn = false;

                        if(_lastQueenPosiition != null && _lastQueenPosiition.Row == rowIndex)
                        {
                            biggerColumn = _lastQueenPosiition.Column;
                        }
                        else
                        {
                            biggerColumn = 0;
                        }

                        foreach (var cell in _table.Table[rowIndex])
                        {
                            if (cell > biggerColumn)
                            {
                                biggerColumn = cell;
                                isBiggerColumn = true;
                                break;
                            }
                        }

                        if (isBiggerColumn)
                        {
                            //show game
                            //Console.WriteLine("Step Forward");
                            //Console.WriteLine(ToString());

                            _stepForward(rowIndex, biggerColumn);
                        }
                        else
                        {
                            //show game
                            //Console.WriteLine("Step Back");
                            //Console.WriteLine(ToString());

                            _stepBack(rowIndex);
                        }
                    }
                    else
                    {
                        //show game
                        //Console.WriteLine("Step Back");
                        //Console.WriteLine(ToString());

                        _stepBack(rowIndex);
                    }

                }

            }
            

        }

        private void addResult()
        {
            _results.Add(String.Join(';', _queens));
        }
    }

}
